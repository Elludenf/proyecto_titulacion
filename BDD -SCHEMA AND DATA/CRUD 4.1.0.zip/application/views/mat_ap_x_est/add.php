<?php echo validation_errors(); ?>

<?php echo form_open('mat_ap_x_est/add'); ?>

	
	<button type="submit">Save</button>

<?php echo form_close(); ?>