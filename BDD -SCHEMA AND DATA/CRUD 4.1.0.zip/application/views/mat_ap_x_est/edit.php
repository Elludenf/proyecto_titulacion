<?php echo validation_errors(); ?>

<?php echo form_open('mat_ap_x_est/edit/'.$mat_ap_x_est['mat_codigo']); ?>

	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>