<?php echo validation_errors(); ?>

<?php echo form_open('escuela/add'); ?>

	<div>
				Facu Codigo : 
				<select name="facu_codigo">
					<option value="">select facultad</option>
					<?php 
					foreach($all_facultad as $facultad)
					{
						$selected = ($facultad['facu_codigo'] == $this->input->post('facu_codigo')) ? ' selected="selected"' : "";

						echo '<option value="'.$facultad['facu_codigo'].'" '.$selected.'>'.$facultad['facu_codigo'].'</option>';
					} 
					?>
				</select>
		</div>
	<div>Esc Descripcion : <input type="text" name="esc_descripcion" value="<?php echo $this->input->post('esc_descripcion'); ?>" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>