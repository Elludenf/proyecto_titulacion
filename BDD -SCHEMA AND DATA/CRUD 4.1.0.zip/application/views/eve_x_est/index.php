<table border="1" width="100%">
    <tr>
		<th>Est Codigo</th>
		<th>Eve Codigo</th>
		<th>Exe Asistencia</th>
		<th>Actions</th>
    </tr>
	<?php foreach($eve_x_est as $e){ ?>
    <tr>
		<td><?php echo $e['est_codigo']; ?></td>
		<td><?php echo $e['eve_codigo']; ?></td>
		<td><?php echo $e['exe_asistencia']; ?></td>
		<td>
            <a href="<?php echo site_url('eve_x_est/edit/'.$e['est_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('eve_x_est/remove/'.$e['est_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>