<?php echo validation_errors(); ?>

<?php echo form_open('eve_x_est/edit/'.$eve_x_est['est_codigo']); ?>

	<div>Exe Asistencia : <input type="checkbox" name="exe_asistencia" value="1" <?php echo ($eve_x_est['exe_asistencia']==1 ? 'checked="checked"' : ''); ?> /></div>
	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>