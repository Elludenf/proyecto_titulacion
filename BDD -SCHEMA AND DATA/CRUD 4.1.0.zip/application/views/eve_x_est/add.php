<?php echo validation_errors(); ?>

<?php echo form_open('eve_x_est/add'); ?>

	<div>Exe Asistencia : <input type="checkbox" name="exe_asistencia" value="1" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>