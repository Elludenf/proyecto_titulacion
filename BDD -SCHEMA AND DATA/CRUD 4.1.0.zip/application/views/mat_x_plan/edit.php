<?php echo validation_errors(); ?>

<?php echo form_open('mat_x_plan/edit/'.$mat_x_plan['plan_codigo']); ?>

	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>