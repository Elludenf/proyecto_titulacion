<table border="1" width="100%">
    <tr>
		<th>Plan Codigo</th>
		<th>Mat Codigo</th>
		<th>Pac Codigo</th>
		<th>Actions</th>
    </tr>
	<?php foreach($mat_x_plan as $m){ ?>
    <tr>
		<td><?php echo $m['plan_codigo']; ?></td>
		<td><?php echo $m['mat_codigo']; ?></td>
		<td><?php echo $m['pac_codigo']; ?></td>
		<td>
            <a href="<?php echo site_url('mat_x_plan/edit/'.$m['plan_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('mat_x_plan/remove/'.$m['plan_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>