<table border="1" width="100%">
    <tr>
		<th>Mat Codigo</th>
		<th>Exa Codigo</th>
		<th>Mxe Fecha 1</th>
		<th>Mxe Fecha 2</th>
		<th>Mxe Nota Oral 1</th>
		<th>Mxe Nota Escrita 1</th>
		<th>Mxe Nota Oral 2</th>
		<th>Mxe Nota Escrita 2</th>
		<th>Mxe Intento</th>
		<th>Actions</th>
    </tr>
	<?php foreach($mat_x_exa as $m){ ?>
    <tr>
		<td><?php echo $m['mat_codigo']; ?></td>
		<td><?php echo $m['exa_codigo']; ?></td>
		<td><?php echo $m['mxe_fecha_1']; ?></td>
		<td><?php echo $m['mxe_fecha_2']; ?></td>
		<td><?php echo $m['mxe_nota_oral_1']; ?></td>
		<td><?php echo $m['mxe_nota_escrita_1']; ?></td>
		<td><?php echo $m['mxe_nota_oral_2']; ?></td>
		<td><?php echo $m['mxe_nota_escrita_2']; ?></td>
		<td><?php echo $m['mxe_intento']; ?></td>
		<td>
            <a href="<?php echo site_url('mat_x_exa/edit/'.$m['mat_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('mat_x_exa/remove/'.$m['mat_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>