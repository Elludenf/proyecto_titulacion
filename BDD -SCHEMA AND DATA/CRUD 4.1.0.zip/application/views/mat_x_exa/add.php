<?php echo validation_errors(); ?>

<?php echo form_open('mat_x_exa/add'); ?>

	<div>Mxe Fecha 1 : <input type="text" name="mxe_fecha_1" value="<?php echo $this->input->post('mxe_fecha_1'); ?>" /></div>
	<div>Mxe Fecha 2 : <input type="text" name="mxe_fecha_2" value="<?php echo $this->input->post('mxe_fecha_2'); ?>" /></div>
	<div>Mxe Nota Oral 1 : <input type="text" name="mxe_nota_oral_1" value="<?php echo $this->input->post('mxe_nota_oral_1'); ?>" /></div>
	<div>Mxe Nota Escrita 1 : <input type="text" name="mxe_nota_escrita_1" value="<?php echo $this->input->post('mxe_nota_escrita_1'); ?>" /></div>
	<div>Mxe Nota Oral 2 : <input type="text" name="mxe_nota_oral_2" value="<?php echo $this->input->post('mxe_nota_oral_2'); ?>" /></div>
	<div>Mxe Nota Escrita 2 : <input type="text" name="mxe_nota_escrita_2" value="<?php echo $this->input->post('mxe_nota_escrita_2'); ?>" /></div>
	<div>Mxe Intento : <input type="text" name="mxe_intento" value="<?php echo $this->input->post('mxe_intento'); ?>" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>