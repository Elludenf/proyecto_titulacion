<table border="1" width="100%">
    <tr>
		<th>Est Codigo</th>
		<th>Carr Codigo</th>
		<th>Est Nombre1</th>
		<th>Est Nombre2</th>
		<th>Est Apellido1</th>
		<th>Est Apellido2</th>
		<th>Est Tipoid</th>
		<th>Est Id</th>
		<th>Est Direccion</th>
		<th>Est Telefono</th>
		<th>Est Celular</th>
		<th>Est Mail</th>
		<th>Est Mailpuce</th>
		<th>Est Fechanac</th>
		<th>Est Sexo</th>
		<th>Est Foto</th>
		<th>Est Fechaingreso</th>
		<th>Est Fechaestimadagraduacion</th>
		<th>Est Fechagraduacion</th>
		<th>Actions</th>
    </tr>
	<?php foreach($estudiante as $e){ ?>
    <tr>
		<td><?php echo $e['est_codigo']; ?></td>
		<td><?php echo $e['carr_codigo']; ?></td>
		<td><?php echo $e['est_nombre1']; ?></td>
		<td><?php echo $e['est_nombre2']; ?></td>
		<td><?php echo $e['est_apellido1']; ?></td>
		<td><?php echo $e['est_apellido2']; ?></td>
		<td><?php echo $e['est_tipoid']; ?></td>
		<td><?php echo $e['est_id']; ?></td>
		<td><?php echo $e['est_direccion']; ?></td>
		<td><?php echo $e['est_telefono']; ?></td>
		<td><?php echo $e['est_celular']; ?></td>
		<td><?php echo $e['est_mail']; ?></td>
		<td><?php echo $e['est_mailpuce']; ?></td>
		<td><?php echo $e['est_fechanac']; ?></td>
		<td><?php echo $e['est_sexo']; ?></td>
		<td><?php echo $e['est_foto']; ?></td>
		<td><?php echo $e['est_fechaingreso']; ?></td>
		<td><?php echo $e['est_fechaestimadagraduacion']; ?></td>
		<td><?php echo $e['est_fechagraduacion']; ?></td>
		<td>
            <a href="<?php echo site_url('estudiante/edit/'.$e['est_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('estudiante/remove/'.$e['est_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>