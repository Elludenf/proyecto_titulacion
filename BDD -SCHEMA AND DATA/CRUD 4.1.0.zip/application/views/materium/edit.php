<?php echo validation_errors(); ?>

<?php echo form_open('materium/edit/'.$materium['mat_codigo']); ?>

	<div>Mat Profesionalizante : <input type="checkbox" name="mat_profesionalizante" value="1" <?php echo ($materium['mat_profesionalizante']==1 ? 'checked="checked"' : ''); ?> /></div>
	<div>Mat Nombre : <input type="text" name="mat_nombre" value="<?php echo ($this->input->post('mat_nombre') ? $this->input->post('mat_nombre') : $materium['mat_nombre']); ?>" /></div>
	<div>Mat Nivel : <input type="text" name="mat_nivel" value="<?php echo ($this->input->post('mat_nivel') ? $this->input->post('mat_nivel') : $materium['mat_nivel']); ?>" /></div>
	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>