<?php echo validation_errors(); ?>

<?php echo form_open('responsable_titulacion/edit/'.$responsable_titulacion['res_codigo']); ?>

	<div>
				Prof Codigo : 
				<select name="prof_codigo">
					<option value="">select profesor</option>
					<?php 
					foreach($all_profesor as $profesor)
					{
						$selected = ($profesor['prof_codigo'] == $responsable_titulacion['prof_codigo']) ? ' selected="selected"' : "";

						echo '<option value="'.$profesor['prof_codigo'].'" '.$selected.'>'.$profesor['prof_codigo'].'</option>';
					} 
					?>
				</select>
		</div>
	<div>
				Pac Codigo : 
				<select name="pac_codigo">
					<option value="">select periodo_academico</option>
					<?php 
					foreach($all_periodo_academico as $periodo_academico)
					{
						$selected = ($periodo_academico['pac_codigo'] == $responsable_titulacion['pac_codigo']) ? ' selected="selected"' : "";

						echo '<option value="'.$periodo_academico['pac_codigo'].'" '.$selected.'>'.$periodo_academico['pac_codigo'].'</option>';
					} 
					?>
				</select>
		</div>
	<div>Res Tipo : <input type="text" name="res_tipo" value="<?php echo ($this->input->post('res_tipo') ? $this->input->post('res_tipo') : $responsable_titulacion['res_tipo']); ?>" /></div>
	<div>Res Fechanombramiento : <input type="text" name="res_fechanombramiento" value="<?php echo ($this->input->post('res_fechanombramiento') ? $this->input->post('res_fechanombramiento') : $responsable_titulacion['res_fechanombramiento']); ?>" /></div>
	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>