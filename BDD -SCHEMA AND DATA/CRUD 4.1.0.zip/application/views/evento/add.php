<?php echo validation_errors(); ?>

<?php echo form_open('evento/add'); ?>

	<div>Eve Fecha : <input type="text" name="eve_fecha" value="<?php echo $this->input->post('eve_fecha'); ?>" /></div>
	<div>Eve Tema : <input type="text" name="eve_tema" value="<?php echo $this->input->post('eve_tema'); ?>" /></div>
	<div>Eve Descripcion : <textarea name="eve_descripcion"><?php echo $this->input->post('eve_descripcion'); ?></textarea></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>