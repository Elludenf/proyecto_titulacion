<table border="1" width="100%">
    <tr>
		<th>Eve Codigo</th>
		<th>Eve Fecha</th>
		<th>Eve Tema</th>
		<th>Eve Descripcion</th>
		<th>Actions</th>
    </tr>
	<?php foreach($evento as $e){ ?>
    <tr>
		<td><?php echo $e['eve_codigo']; ?></td>
		<td><?php echo $e['eve_fecha']; ?></td>
		<td><?php echo $e['eve_tema']; ?></td>
		<td><?php echo $e['eve_descripcion']; ?></td>
		<td>
            <a href="<?php echo site_url('evento/edit/'.$e['eve_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('evento/remove/'.$e['eve_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>