<?php echo validation_errors(); ?>

<?php echo form_open('evento/edit/'.$evento['eve_codigo']); ?>

	<div>Eve Fecha : <input type="text" name="eve_fecha" value="<?php echo ($this->input->post('eve_fecha') ? $this->input->post('eve_fecha') : $evento['eve_fecha']); ?>" /></div>
	<div>Eve Tema : <input type="text" name="eve_tema" value="<?php echo ($this->input->post('eve_tema') ? $this->input->post('eve_tema') : $evento['eve_tema']); ?>" /></div>
	<div>Eve Descripcion : <textarea name="eve_descripcion"><?php echo ($this->input->post('eve_descripcion') ? $this->input->post('eve_descripcion') : $evento['eve_descripcion']); ?></textarea></div>
	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>