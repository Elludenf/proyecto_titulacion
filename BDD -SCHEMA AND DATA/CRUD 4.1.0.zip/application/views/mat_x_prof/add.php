<?php echo validation_errors(); ?>

<?php echo form_open('mat_x_prof/add'); ?>

	
	<button type="submit">Save</button>

<?php echo form_close(); ?>