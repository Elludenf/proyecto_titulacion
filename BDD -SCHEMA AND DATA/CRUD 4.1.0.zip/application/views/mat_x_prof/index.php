<table border="1" width="100%">
    <tr>
		<th>Prof Codigo</th>
		<th>Mat Codigo</th>
		<th>Actions</th>
    </tr>
	<?php foreach($mat_x_prof as $m){ ?>
    <tr>
		<td><?php echo $m['prof_codigo']; ?></td>
		<td><?php echo $m['mat_codigo']; ?></td>
		<td>
            <a href="<?php echo site_url('mat_x_prof/edit/'.$m['prof_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('mat_x_prof/remove/'.$m['prof_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>