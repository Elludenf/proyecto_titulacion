<?php echo validation_errors(); ?>

<?php echo form_open('mat_x_prof/edit/'.$mat_x_prof['prof_codigo']); ?>

	
	<button type="submit">Save</button>
	
<?php echo form_close(); ?>