<table border="1" width="100%">
    <tr>
		<th>Opg Codigo</th>
		<th>Dis Codigo</th>
		<th>Elb Nota Oral</th>
		<th>Elb Nota Escrito</th>
		<th>Actions</th>
    </tr>
	<?php foreach($trab_x_opc as $t){ ?>
    <tr>
		<td><?php echo $t['opg_codigo']; ?></td>
		<td><?php echo $t['dis_codigo']; ?></td>
		<td><?php echo $t['elb_nota_oral']; ?></td>
		<td><?php echo $t['elb_nota_escrito']; ?></td>
		<td>
            <a href="<?php echo site_url('trab_x_opc/edit/'.$t['opg_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('trab_x_opc/remove/'.$t['opg_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>