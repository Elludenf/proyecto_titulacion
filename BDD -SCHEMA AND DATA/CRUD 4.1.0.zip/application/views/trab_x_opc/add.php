<?php echo validation_errors(); ?>

<?php echo form_open('trab_x_opc/add'); ?>

	<div>Elb Nota Oral : <input type="text" name="elb_nota_oral" value="<?php echo $this->input->post('elb_nota_oral'); ?>" /></div>
	<div>Elb Nota Escrito : <input type="text" name="elb_nota_escrito" value="<?php echo $this->input->post('elb_nota_escrito'); ?>" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>