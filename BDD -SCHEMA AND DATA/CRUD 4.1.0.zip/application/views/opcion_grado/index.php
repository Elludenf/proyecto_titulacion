<table border="1" width="100%">
    <tr>
		<th>Opg Codigo</th>
		<th>Est Codigo</th>
		<th>Opg Eleccion</th>
		<th>Actions</th>
    </tr>
	<?php foreach($opcion_grado as $o){ ?>
    <tr>
		<td><?php echo $o['opg_codigo']; ?></td>
		<td><?php echo $o['est_codigo']; ?></td>
		<td><?php echo $o['opg_eleccion']; ?></td>
		<td>
            <a href="<?php echo site_url('opcion_grado/edit/'.$o['opg_codigo']); ?>">Edit</a> | 
            <a href="<?php echo site_url('opcion_grado/remove/'.$o['opg_codigo']); ?>">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>