<?php echo validation_errors(); ?>

<?php echo form_open('opcion_grado/add'); ?>

	<div>
				Est Codigo : 
				<select name="est_codigo">
					<option value="">select estudiante</option>
					<?php 
					foreach($all_estudiante as $estudiante)
					{
						$selected = ($estudiante['est_codigo'] == $this->input->post('est_codigo')) ? ' selected="selected"' : "";

						echo '<option value="'.$estudiante['est_codigo'].'" '.$selected.'>'.$estudiante['est_codigo'].'</option>';
					} 
					?>
				</select>
		</div>
	<div>Opg Eleccion : <input type="text" name="opg_eleccion" value="<?php echo $this->input->post('opg_eleccion'); ?>" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>