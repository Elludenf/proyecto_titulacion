<?php echo validation_errors(); ?>

<?php echo form_open('revdir_x_di/add'); ?>

	<div>Rxd Tipo : <input type="text" name="rxd_tipo" value="<?php echo $this->input->post('rxd_tipo'); ?>" /></div>
	<div>Rxd Fechanombramiento : <input type="text" name="rxd_fechanombramiento" value="<?php echo $this->input->post('rxd_fechanombramiento'); ?>" /></div>
	
	<button type="submit">Save</button>

<?php echo form_close(); ?>